package cs174a;

import java.util.ArrayList;


public class CustomerMonthlyStatement{
	public String c_id;
	public ArrayList<AccountStatement> statements;

	public CustomerMonthlyStatement(){

	}
}