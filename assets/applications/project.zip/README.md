#Team members: 
* Jose Recinos Cuellar (8907826)
* Nicholas Duncan (3937679)

### We completed all basic requirements from the project specs as well as the discussions/changes on piazza


### From the testable interface, we implemented ALL the functions
* initializeSystem
* dropTables
* createTables
* setDate
* createCheckingSavingsAccount
* createPocketAccount
* createCustomer
* deposit
* showBalance
* topUp
* payFriend
* listClosedAccounts

### Anything important that might prevent running: No
* Provided the two commands supplied are executed in the `project` directory, it should run correctly

### App should run with just the two given commands: Yes
* If for whatever reason, it doesn't run, it can be executed with make && make run
